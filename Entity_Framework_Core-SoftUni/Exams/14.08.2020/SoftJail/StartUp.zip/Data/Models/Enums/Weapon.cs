﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife = 0,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}
