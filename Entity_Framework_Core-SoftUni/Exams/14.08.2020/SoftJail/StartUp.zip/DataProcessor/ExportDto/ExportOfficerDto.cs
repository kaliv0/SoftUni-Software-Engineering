﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.DataProcessor.ExportDto
{
    public class ExportOfficerDto
    {
        public string OfficerName { get; set; }
        public string Department { get; set; }
    }
}
