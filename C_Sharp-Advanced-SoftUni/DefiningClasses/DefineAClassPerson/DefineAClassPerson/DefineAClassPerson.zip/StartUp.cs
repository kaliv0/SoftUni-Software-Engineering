﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var firstPerson = new Person("Pesho", 20);
            var secondPerson = new Person("Gosho", 18);
            var thirdPerson = new Person("Stamat", 43);
        }
    }
}
