﻿using System;
using System.Collections.Generic;
using System.Text;

using MilitaryElite.Enums;

namespace MilitaryElite.Contracts
{
   public  interface ISpecialisedSoldier
    {
        string Corp { get; }
    }
}
